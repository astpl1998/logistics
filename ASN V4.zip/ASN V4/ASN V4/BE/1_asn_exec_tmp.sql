 
 if exists (select * from sys.tables where name = 'asn_exec_tmp' and type	=	'U' )
 begin 
 drop table asn_exec_tmp
 end  

 go 
	create table asn_exec_tmp
	(
	asn_no			documentno,
	guid			GUID
	)