if exists ( select 'y' from sysobjects where name = 'report_format_combo_init_iedk' and type = 'P')
	drop proc report_format_combo_init_iedk
go

/********************************************************************************/
/* Procedure    :report_format_combo_init_iedk                                  */
/* Description  :                                                               */
/********************************************************************************/
/* Customer     :dvita                                                          */
/* Project      :dvita                                                          */
/********************************************************************************/
/* Referenced   :                                                               */
/* Tables       :                                                               */
/********************************************************************************/
/* Development History                                                          */
/********************************************************************************/
/* Author       :amitysoft                                                      */
/* Date         :4/30/2018 10:34:12 AM                                          */
/********************************************************************************/
/* Modification History                                                         */
/********************************************************************************/
/* Modified by  :                                                               */
/* Date         :                                                               */
/* Description  :                                                               */
/********************************************************************************/

CREATE procedure report_format_combo_init_iedk                                        
	@ctxt_user                     Ctxt_User,
	@ctxt_service                  Ctxt_Service,
	@ctxt_role                     Ctxt_Role,
	@ctxt_ouinstance               Ctxt_OUInstance,
	@ctxt_language                 Ctxt_Language,
	@m_errorid                     int output

as
Begin

	Set nocount on

	Select @ctxt_user                     =ltrim(rtrim(@ctxt_user))
	Select @ctxt_service                  =ltrim(rtrim(@ctxt_service))
	Select @ctxt_role                     =ltrim(rtrim(@ctxt_role))
	-- @m_errorid should be 0 to Indicate Success
	Set @m_errorid = 0


	--null checking
	If @ctxt_user='~#~'
		Select @ctxt_user=null
	If @ctxt_service='~#~'
		Select @ctxt_service=null
	If @ctxt_role='~#~'
		Select @ctxt_role=null
	If @ctxt_ouinstance=-915
		Select @ctxt_ouinstance=null
	If @ctxt_language=-915
		Select @ctxt_language=null


		declare @temp table 
		(
		sno				int,
		_reportformat	nvarchar(200)
		)


		insert into @temp 
		values (1,'ASN Format'),(2,'ASN Worksheet')

		
		
		Select  
		_reportformat            '_reportformat',
		_reportformat					 'report_format_hdn'

		from @temp
	--errors mapped

	--output parameters
	/*
	Select  
		_reportformat                 '_reportformat',
		report_format_hdn             'report_format_hdn'

	*/
	Set nocount off
End


go
if exists ( select 'y' from sysobjects where name = 'report_format_combo_init_iedk' and type = 'P')
	grant exec on report_format_combo_init_iedk to public
go
