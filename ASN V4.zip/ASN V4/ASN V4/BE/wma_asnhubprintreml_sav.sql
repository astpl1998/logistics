if exists ( select 'y' from sysobjects where name = 'wma_asnhubprintreml_sav' and type = 'P')
	drop proc wma_asnhubprintreml_sav
go
/********************************************************************************/
/* Procedure    :WMA_ASNHubPrintREML_Sav                                        */
/* Description  :                                                               */
/********************************************************************************/
/* Customer     :dvita                                                          */
/* Project      :dvita                                                          */
/********************************************************************************/
/* Referenced   :                                                               */
/* Tables       :                                                               */
/********************************************************************************/
/* Development History                                                          */
/********************************************************************************/
/* Author       :Amitysoft                                                      */
/* Date         :4/20/2018 4:13:27 PM                                           */
/********************************************************************************/
/* Modification History                                                         */
/********************************************************************************/
/* Modified by  :                                                               */
/* Date         :                                                               */
/* Description  :                                                               */
/********************************************************************************/

CREATE procedure wma_asnhubprintreml_sav                                        
	@ctxt_user                     Ctxt_User,
	@ctxt_service                  Ctxt_Service,
	@ctxt_role                     Ctxt_Role,
	@ctxt_ouinstance               Ctxt_OUInstance,
	@ctxt_language                 Ctxt_Language,
	@_reportformat                 _desc255,
	@asn_asndate_ml                date,
	@asn_asndatefrom               date,
	@asn_asndateto                 date,
	@asn_asnno_ml                  documentno,
	@asn_asnnofrom                 desc20,
	@asn_asnnoto                   desc20,
	@asn_customercode              desc20,
	@asn_customercode_ml           documentno,
	@asn_customeritemcode_ml       ItemCode,
	@asn_customername              desc40,
	@asn_customername_ml           desc40,
	@asn_equipmentnumber_hdr       MoCode,
	@asn_equipmenttype_hdr         desc40,
	@asn_expecteddeliverydate_ml   DateTime1,
	@asn_hdn_char_01               desc255,
	@asn_hdn_char_02               desc255,
	@asn_hdn_char_03               desc255,
	@asn_hdn_int_01                HrInt,
	@asn_hdn_int_02                HrInt,
	@asn_hidden_1                  HrInt,
	@asn_hub_deliverydate_hdr      date,
	@asn_inboundorderdate_ml       date,
	@asn_inboundorderdatefrom      date,
	@asn_inboundorderdateto        date,
	@asn_inboundorderno_ml         documentno,
	@asn_inboundordernofrom        desc20,
	@asn_inboundordernoto          desc20,
	@asn_itemcode_ml               ItemCode,
	@asn_itemdesc_ml               desc255,
	@asn_masteruom_ml              Uomcode,
	@asn_orderqty_ml               wms_quantity,
	@asn_primaryrefdocdatefromhdr  date,
	@asn_primaryrefdocno_ml        documentno,
	@asn_primaryrefdocnofrom       desc20,
	@asn_primaryrefdocnoto         date,
	@asn_primaryrefdoctype         desc20,
	@asn_primaryrefdoctype_ml      desc255,
	@asn_reporton_btn              desc255,
	@asn_status                    desc20,
	@asn_status_ml                 desc255,
	@asn_thuqty_ml                 wms_quantity,
	@asn_thutype_ml                desc40,
	@asn_vehiclenumber_hdr         ParamCode,
	@asn_vehicletype_hdr           desc40,
	@asn_vendorcode                suppliercode,
	@asn_vendorcode_ml             suppliercode,
	@asn_vendorname                SupplierName,
	@asn_vendorname_ml             SupplierName,
	@carriername_asn_hdr           Customer_Name,
	@description                   desc255,
	@equipmentnumber_asn_ml        MoCode,
	@equipmenttype_asn_ml          desc40,
	@guid                          GUID,
	@hdnbu                         desc255,
	@hdncc                         desc255,
	@hdncsouinstance               Ctxt_OUInstance,
	@hdnguid                       desc255,
	@hdnhiddencontrol1             desc255,
	@hdnhiddencontrol2             desc255,
	@hdnlo                         desc255,
	@hdnou                         Ctxt_OUInstance,
	@hdnrecloc                     desc255,
	@hdnsrcloc                     desc255,
	@hdntimestamp                  Timestamp,
	@hiddencontrol1                desc255,
	@hiddencontrol2                desc255,
	@hiddencontrol3                desc255,
	@hiddencontrol4                desc255,
	@hiddencontrol5                desc255,
	@internalnotes_asn_ml          desc255,
	@location                      Warehouse,
	@modeflag                      ModeFlag,
	@oucodehide                    Ctxt_OUInstance,
	@prj_hdn_ctrl                  desc255,
	@report_format_hdn             _desc255,
	@srccompcode                   desc255,
	@txtdtformat                   desc255,
	@txtdtformatinthide            desc255,
	@txttimestamp                  Timestamp,
	@vendorasnno_asn_hdr           documentno,
	@__fprowno                     rowno,
	@fprowno                       rowno,
	@m_errorid                     int output

as
Begin

	Set nocount on

	Select @ctxt_user                     =ltrim(rtrim(@ctxt_user))
	Select @ctxt_service                  =ltrim(rtrim(@ctxt_service))
	Select @ctxt_role                     =ltrim(rtrim(@ctxt_role))
	Select @_reportformat                 =ltrim(rtrim(@_reportformat))
	Select @asn_asnno_ml                  =ltrim(rtrim(@asn_asnno_ml))
	Select @asn_asnnofrom                 =ltrim(rtrim(@asn_asnnofrom))
	Select @asn_asnnoto                   =ltrim(rtrim(@asn_asnnoto))
	Select @asn_customercode              =ltrim(rtrim(@asn_customercode))
	Select @asn_customercode_ml           =ltrim(rtrim(@asn_customercode_ml))
	Select @asn_customeritemcode_ml       =ltrim(rtrim(@asn_customeritemcode_ml))
	Select @asn_customername              =ltrim(rtrim(@asn_customername))
	Select @asn_customername_ml           =ltrim(rtrim(@asn_customername_ml))
	Select @asn_equipmentnumber_hdr       =ltrim(rtrim(@asn_equipmentnumber_hdr))
	Select @asn_equipmenttype_hdr         =ltrim(rtrim(@asn_equipmenttype_hdr))
	Select @asn_hdn_char_01               =ltrim(rtrim(@asn_hdn_char_01))
	Select @asn_hdn_char_02               =ltrim(rtrim(@asn_hdn_char_02))
	Select @asn_hdn_char_03               =ltrim(rtrim(@asn_hdn_char_03))
	Select @asn_inboundorderno_ml         =ltrim(rtrim(@asn_inboundorderno_ml))
	Select @asn_inboundordernofrom        =ltrim(rtrim(@asn_inboundordernofrom))
	Select @asn_inboundordernoto          =ltrim(rtrim(@asn_inboundordernoto))
	Select @asn_itemcode_ml               =ltrim(rtrim(@asn_itemcode_ml))
	Select @asn_itemdesc_ml               =ltrim(rtrim(@asn_itemdesc_ml))
	Select @asn_masteruom_ml              =ltrim(rtrim(@asn_masteruom_ml))
	Select @asn_primaryrefdocno_ml        =ltrim(rtrim(@asn_primaryrefdocno_ml))
	Select @asn_primaryrefdocnofrom       =ltrim(rtrim(@asn_primaryrefdocnofrom))
	Select @asn_primaryrefdoctype         =ltrim(rtrim(@asn_primaryrefdoctype))
	Select @asn_primaryrefdoctype_ml      =ltrim(rtrim(@asn_primaryrefdoctype_ml))
	Select @asn_reporton_btn              =ltrim(rtrim(@asn_reporton_btn))
	Select @asn_status                    =ltrim(rtrim(@asn_status))
	Select @asn_status_ml                 =ltrim(rtrim(@asn_status_ml))
	Select @asn_thutype_ml                =ltrim(rtrim(@asn_thutype_ml))
	Select @asn_vehiclenumber_hdr =ltrim(rtrim(@asn_vehiclenumber_hdr))
	Select @asn_vehicletype_hdr           =ltrim(rtrim(@asn_vehicletype_hdr))
	Select @asn_vendorcode                =ltrim(rtrim(@asn_vendorcode))
	Select @asn_vendorcode_ml             =ltrim(rtrim(@asn_vendorcode_ml))
	Select @asn_vendorname                =ltrim(rtrim(@asn_vendorname))
	Select @asn_vendorname_ml             =ltrim(rtrim(@asn_vendorname_ml))
	Select @carriername_asn_hdr           =ltrim(rtrim(@carriername_asn_hdr))
	Select @description                   =ltrim(rtrim(@description))
	Select @equipmentnumber_asn_ml        =ltrim(rtrim(@equipmentnumber_asn_ml))
	Select @equipmenttype_asn_ml          =ltrim(rtrim(@equipmenttype_asn_ml))
	Select @guid                          =ltrim(rtrim(@guid))
	Select @hdnbu                         =ltrim(rtrim(@hdnbu))
	Select @hdncc                         =ltrim(rtrim(@hdncc))
	Select @hdnguid                       =ltrim(rtrim(@hdnguid))
	Select @hdnhiddencontrol1             =ltrim(rtrim(@hdnhiddencontrol1))
	Select @hdnhiddencontrol2             =ltrim(rtrim(@hdnhiddencontrol2))
	Select @hdnlo                         =ltrim(rtrim(@hdnlo))
	Select @hdnrecloc                     =ltrim(rtrim(@hdnrecloc))
	Select @hdnsrcloc                     =ltrim(rtrim(@hdnsrcloc))
	Select @hiddencontrol1                =ltrim(rtrim(@hiddencontrol1))
	Select @hiddencontrol2                =ltrim(rtrim(@hiddencontrol2))
	Select @hiddencontrol3                =ltrim(rtrim(@hiddencontrol3))
	Select @hiddencontrol4                =ltrim(rtrim(@hiddencontrol4))
	Select @hiddencontrol5                =ltrim(rtrim(@hiddencontrol5))
	Select @internalnotes_asn_ml          =ltrim(rtrim(@internalnotes_asn_ml))
	Select @location                      =ltrim(rtrim(@location))
	Select @modeflag                      =ltrim(rtrim(@modeflag))
	Select @prj_hdn_ctrl                  =ltrim(rtrim(@prj_hdn_ctrl))
	Select @report_format_hdn             =ltrim(rtrim(@report_format_hdn))
	Select @srccompcode                   =ltrim(rtrim(@srccompcode))
	Select @txtdtformat                   =ltrim(rtrim(@txtdtformat))
	Select @txtdtformatinthide            =ltrim(rtrim(@txtdtformatinthide))
	Select @vendorasnno_asn_hdr           =ltrim(rtrim(@vendorasnno_asn_hdr))
	-- @m_errorid should be 0 to Indicate Success
	Set @m_errorid = 0


	--null checking
	If @ctxt_user='~#~'
		Select @ctxt_user=null
	If @ctxt_service='~#~'
		Select @ctxt_service=null
	If @ctxt_role='~#~'
		Select @ctxt_role=null
	If @ctxt_ouinstance=-915
		Select @ctxt_ouinstance=null
	If @ctxt_language=-915
		Select @ctxt_language=null
	If @_reportformat='~#~'
		Select @_reportformat=null
	If @asn_asndate_ml='1900-01-01'
		Select @asn_asndate_ml=null
	If @asn_asndatefrom='1900-01-01'
		Select @asn_asndatefrom=null
	If @asn_asndateto='1900-01-01'
		Select @asn_asndateto=null
	If @asn_asnno_ml='~#~'
		Select @asn_asnno_ml=null
	If @asn_asnnofrom='~#~'
		Select @asn_asnnofrom=null
	If @asn_asnnoto='~#~'
		Select @asn_asnnoto=null
	If @asn_customercode='~#~'
		Select @asn_customercode=null
	If @asn_customercode_ml='~#~'
		Select @asn_customercode_ml=null
	If @asn_customeritemcode_ml='~#~'
		Select @asn_customeritemcode_ml=null
	If @asn_customername='~#~'
		Select @asn_customername=null
	If @asn_customername_ml='~#~'
		Select @asn_customername_ml=null
	If @asn_equipmentnumber_hdr='~#~'
		Select @asn_equipmentnumber_hdr=null
	If @asn_equipmenttype_hdr='~#~'
		Select @asn_equipmenttype_hdr=null
	If @asn_expecteddeliverydate_ml='1900-01-01'
		Select @asn_expecteddeliverydate_ml=null
	If @asn_hdn_char_01='~#~'
		Select @asn_hdn_char_01=null
	If @asn_hdn_char_02='~#~'
		Select @asn_hdn_char_02=null
	If @asn_hdn_char_03='~#~'
		Select @asn_hdn_char_03=null
	If @asn_hdn_int_01=-915
		Select @asn_hdn_int_01=null
	If @asn_hdn_int_02=-915
		Select @asn_hdn_int_02=null
	If @asn_hidden_1=-915
		Select @asn_hidden_1=null
	If @asn_hub_deliverydate_hdr='1900-01-01'
		Select @asn_hub_deliverydate_hdr=null
	If @asn_inboundorderdate_ml='1900-01-01'
		Select @asn_inboundorderdate_ml=null
	If @asn_inboundorderdatefrom='1900-01-01'
		Select @asn_inboundorderdatefrom=null
	If @asn_inboundorderdateto='1900-01-01'
		Select @asn_inboundorderdateto=null
	If @asn_inboundorderno_ml='~#~'
		Select @asn_inboundorderno_ml=null
	If @asn_inboundordernofrom='~#~'
		Select @asn_inboundordernofrom=null
	If @asn_inboundordernoto='~#~'
		Select @asn_inboundordernoto=null
	If @asn_itemcode_ml='~#~'
		Select @asn_itemcode_ml=null
	If @asn_itemdesc_ml='~#~'
		Select @asn_itemdesc_ml=null
	If @asn_masteruom_ml='~#~'
		Select @asn_masteruom_ml=null
	If @asn_orderqty_ml=-915
		Select @asn_orderqty_ml=null
	If @asn_primaryrefdocdatefromhdr='1900-01-01'
		Select @asn_primaryrefdocdatefromhdr=null
	If @asn_primaryrefdocno_ml='~#~'
		Select @asn_primaryrefdocno_ml=null
	If @asn_primaryrefdocnofrom='~#~'
		Select @asn_primaryrefdocnofrom=null
	If @asn_primaryrefdocnoto='1900-01-01'
		Select @asn_primaryrefdocnoto=null
	If @asn_primaryrefdoctype='~#~'
		Select @asn_primaryrefdoctype=null
	If @asn_primaryrefdoctype_ml='~#~'
		Select @asn_primaryrefdoctype_ml=null
	If @asn_reporton_btn='~#~'
		Select @asn_reporton_btn=null
	If @asn_status='~#~'
		Select @asn_status=null
	If @asn_status_ml='~#~'
		Select @asn_status_ml=null
	If @asn_thuqty_ml=-915
		Select @asn_thuqty_ml=null
	If @asn_thutype_ml='~#~'
		Select @asn_thutype_ml=null
	If @asn_vehiclenumber_hdr='~#~'
		Select @asn_vehiclenumber_hdr=null
	If @asn_vehicletype_hdr='~#~'
		Select @asn_vehicletype_hdr=null
	If @asn_vendorcode='~#~'
		Select @asn_vendorcode=null
	If @asn_vendorcode_ml='~#~'
		Select @asn_vendorcode_ml=null
	If @asn_vendorname='~#~'
		Select @asn_vendorname=null
	If @asn_vendorname_ml='~#~'
		Select @asn_vendorname_ml=null
	If @carriername_asn_hdr='~#~'
		Select @carriername_asn_hdr=null
	If @description='~#~'
		Select @description=null
	If @equipmentnumber_asn_ml='~#~'
		Select @equipmentnumber_asn_ml=null
	If @equipmenttype_asn_ml='~#~'
		Select @equipmenttype_asn_ml=null
	If @guid='~#~'
		Select @guid=null
	If @hdnbu='~#~'
		Select @hdnbu=null
	If @hdncc='~#~'
		Select @hdncc=null
	If @hdncsouinstance=-915
		Select @hdncsouinstance=null
	If @hdnguid='~#~'
		Select @hdnguid=null
	If @hdnhiddencontrol1='~#~'
		Select @hdnhiddencontrol1=null
	If @hdnhiddencontrol2='~#~'
		Select @hdnhiddencontrol2=null
	If @hdnlo='~#~'
		Select @hdnlo=null
	If @hdnou=-915
		Select @hdnou=null
	If @hdnrecloc='~#~'
		Select @hdnrecloc=null
	If @hdnsrcloc='~#~'
		Select @hdnsrcloc=null
	If @hdntimestamp=-915
		Select @hdntimestamp=null
	If @hiddencontrol1='~#~'
		Select @hiddencontrol1=null
	If @hiddencontrol2='~#~'
		Select @hiddencontrol2=null
	If @hiddencontrol3='~#~'
		Select @hiddencontrol3=null
	If @hiddencontrol4='~#~'
		Select @hiddencontrol4=null
	If @hiddencontrol5='~#~'
		Select @hiddencontrol5=null
	If @internalnotes_asn_ml='~#~'
		Select @internalnotes_asn_ml=null
	If @location='~#~'
		Select @location=null
	If @modeflag='~#~'
		Select @modeflag=null
	If @oucodehide=-915
		Select @oucodehide=null
	If @prj_hdn_ctrl='~#~'
		Select @prj_hdn_ctrl=null
	If @report_format_hdn='~#~'
		Select @report_format_hdn=null
	If @srccompcode='~#~'
		Select @srccompcode=null
	If @txtdtformat='~#~'
		Select @txtdtformat=null
	If @txtdtformatinthide='~#~'
		Select @txtdtformatinthide=null
	If @txttimestamp=-915
		Select @txttimestamp=null
	If @vendorasnno_asn_hdr='~#~'
		Select @vendorasnno_asn_hdr=null
	If @__fprowno=-915
		Select @__fprowno=null
	If @fprowno=-915
		Select @fprowno=null




		if @modeflag = 'z'
		begin 
			--create table asn_exec_tmp
			--(
			--asn_no			documentno,
			--guid			GUID
			
			--)
			insert into asn_exec_tmp 
			(
			asn_no,	
			guid	
			)
			select 
			@asn_asnno_ml,
			@hdnguid
		end 



	--output parameters
	/*
	Select  
		__fprowno                     '__fprowno',
		fprowno                       'fprowno'

	*/
	Set nocount off
End






go
if exists ( select 'y' from sysobjects where name = 'wma_asnhubprintreml_sav' and type = 'P')
	grant exec on wma_asnhubprintreml_sav to public
go
