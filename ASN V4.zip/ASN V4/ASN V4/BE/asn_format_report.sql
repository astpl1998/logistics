if exists ( select 'y' from sysobjects where name = 'asn_format_report' and type = 'P')
	drop proc asn_format_report
go

create procedure asn_format_report                                        
	@ctxt_user                     Ctxt_User,
	@ctxt_role                     Ctxt_Role,
	@ctxt_ouinstance               Ctxt_OUInstance,
	@ctxt_language                 Ctxt_Language,
	@_reportformat                 _desc255,
	@asn_asndate_ml                date,
	@asn_asndatefrom               date,
   -- @asn_asndateto                 date,
	@asn_asnno_ml                  documentno,
	@asn_asnnofrom                 desc20
	--@asn_asnnoto                   desc20,
	--@asn_customercode              desc20,
	--@asn_customercode_ml           documentno,
	--@asn_customeritemcode_ml       ItemCode,
	--@asn_customername              desc40,
	--@asn_customername_ml           desc40,
	--@asn_equipmentnumber_hdr       MoCode,
	--@asn_equipmenttype_hdr         desc40,
	--@asn_expecteddeliverydate_ml   DateTime1,
	--@asn_hdn_char_01               desc255,
	--@asn_hdn_char_02               desc255,
	--@asn_hdn_char_03               desc255,
	--@asn_hdn_int_01                HrInt,
	--@asn_hdn_int_02                HrInt,
	--@asn_hidden_1                  HrInt,
	--@asn_hub_deliverydate_hdr      date,
	--@asn_inboundorderdate_ml       date,
	--@asn_inboundorderdatefrom      date,
	--@asn_inboundorderdateto        date,
	--@asn_inboundorderno_ml         documentno,
	--@asn_inboundordernofrom        desc20,
	--@asn_inboundordernoto          desc20,
	--@asn_itemcode_ml               ItemCode,
	--@asn_itemdesc_ml               desc255,
	--@asn_masteruom_ml              Uomcode,
	--@asn_orderqty_ml               wms_quantity,
	--@asn_primaryrefdocdatefromhdr  date,
	--@asn_primaryrefdocno_ml        documentno,
	--@asn_primaryrefdocnofrom       desc20,
	--@asn_primaryrefdocnoto         date,
	--@asn_primaryrefdoctype         desc20,
	--@asn_primaryrefdoctype_ml      desc255,
	--@asn_reporton_btn              desc255,
	--@asn_status                    desc20,
	--@asn_status_ml                 desc255,
	--@asn_thuqty_ml                 wms_quantity,
	--@asn_thutype_ml                desc40,
	--@asn_vehiclenumber_hdr         ParamCode,
	--@asn_vehicletype_hdr           desc40,
	--@asn_vendorcode                suppliercode,
	--@asn_vendorcode_ml             suppliercode,
	--@asn_vendorname                SupplierName,
	--@asn_vendorname_ml             SupplierName,
	--@carriername_asn_hdr           Customer_Name,
	--@description                   desc255,
	--@equipmentnumber_asn_ml        MoCode,
	--@equipmenttype_asn_ml          desc40,
	--@guid                          GUID,
	--@hdnbu                         desc255,
	--@hdncc                         desc255,
	--@hdncsouinstance               Ctxt_OUInstance,
	--@hdnguid                       desc255,
	--@hdnhiddencontrol1             desc255,
	--@hdnhiddencontrol2             desc255,
	--@hdnlo                         desc255,
	--@hdnou                         Ctxt_OUInstance,
	--@hdnrecloc                     desc255,
	--@hdnsrcloc                     desc255,
	----@hdntimestamp                  Timestamp,
	--@hiddencontrol1                desc255,
	--@hiddencontrol2                desc255,
	--@hiddencontrol3                desc255,
	--@hiddencontrol4                desc255,
	--@hiddencontrol5                desc255,
	--@internalnotes_asn_ml          desc255,
	--@location                      Warehouse,
	--@modeflag                      ModeFlag,
	--@oucodehide                    Ctxt_OUInstance,
	--@prj_hdn_ctrl                  desc255,
	--@report_format_hdn             _desc255,
	--@srccompcode                   desc255,
	--@txtdtformat                   desc255,
	--@txtdtformatinthide            desc255,
	----@txttimestamp                  Timestamp,
	--@vendorasnno_asn_hdr           documentno,
	--@__fprowno                     rowno,
	--@fprowno                       rowno,
	--@m_errorid                     int output

as 
begin
set nocount on
    Select @ctxt_user                     =ltrim(rtrim(@ctxt_user))
	--Select @ctxt_service                  =ltrim(rtrim(@ctxt_service))
	Select @ctxt_role                     =ltrim(rtrim(@ctxt_role))
	

	
if	@ctxt_user						= '~#~' select	@ctxt_user                    = null
if	@ctxt_role                    	= '~#~' select	@ctxt_role                    = null
if	@ctxt_ouinstance              	= -915  select	@ctxt_ouinstance              = null
if	@ctxt_language                	= -915 select	@ctxt_language                = null
if	@_reportformat                	= '~#~' select	@_reportformat                = null
if	@asn_asndate_ml               	= '1900-01-01' select	@asn_asndate_ml               = null
if	@asn_asndatefrom              	= '1900-01-01' select	@asn_asndatefrom              = null
--if	@asn_asndateto                	= '1900-01-01' select	@asn_asndateto                = null
if	@asn_asnno_ml                 	= '~#~' select	@asn_asnno_ml                 = null
if	@asn_asnnofrom                	= '~#~' select	@asn_asnnofrom                = null
--if	@asn_asnnoto                  	= '~#~' select	@asn_asnnoto                  = null
--if	@asn_customercode             	= '~#~' select	@asn_customercode             = null
--if	@asn_customercode_ml          	= '~#~' select	@asn_customercode_ml          = null
--if	@asn_customeritemcode_ml      	= '~#~' select	@asn_customeritemcode_ml      = null
--if	@asn_customername             	= '~#~' select	@asn_customername             = null
--if	@asn_customername_ml          	= '~#~' select	@asn_customername_ml          = null
--if	@asn_equipmentnumber_hdr      	= '~#~' select	@asn_equipmentnumber_hdr      = null
--if	@asn_equipmenttype_hdr        	= '~#~' select	@asn_equipmenttype_hdr        = null
--if	@asn_expecteddeliverydate_ml  	= '~#~' select	@asn_expecteddeliverydate_ml  = null
--if	@asn_hdn_char_01              	= '~#~' select	@asn_hdn_char_01              = null
--if	@asn_hdn_char_02              	= '~#~' select	@asn_hdn_char_02              = null
--if	@asn_hdn_char_03              	= '~#~' select	@asn_hdn_char_03              = null
--if	@asn_hdn_int_01               	= '~#~' select	@asn_hdn_int_01               = null
--if	@asn_hdn_int_02               	= '~#~' select	@asn_hdn_int_02               = null
--if	@asn_hidden_1                 	= '~#~' select	@asn_hidden_1                 = null
--if	@asn_hub_deliverydate_hdr     	= '~#~' select	@asn_hub_deliverydate_hdr     = null
--if	@asn_inboundorderdate_ml      	= '~#~' select	@asn_inboundorderdate_ml      = null
--if	@asn_inboundorderdatefrom     	= '1900-01-01' select	@asn_inboundorderdatefrom     = null
--if	@asn_inboundorderdateto       	= '1900-01-01' select	@asn_inboundorderdateto       = null
--if	@asn_inboundorderno_ml        	= '~#~' select	@asn_inboundorderno_ml        = null
--if	@asn_inboundordernofrom       	= '1900-01-01' select	@asn_inboundordernofrom       = null
--if	@asn_inboundordernoto         	= '1900-01-01' select	@asn_inboundordernoto         = null
--if	@asn_itemcode_ml              	= '~#~' select	@asn_itemcode_ml              = null
--if	@asn_itemdesc_ml              	= '~#~' select	@asn_itemdesc_ml              = null
--if	@asn_masteruom_ml             	= '~#~' select	@asn_masteruom_ml             = null
--if	@asn_orderqty_ml              	= '~#~' select	@asn_orderqty_ml              = null
--if	@asn_primaryrefdocdatefromhdr 	= '~#~' select	@asn_primaryrefdocdatefromhdr = null
--if	@asn_primaryrefdocno_ml       	= '~#~' select	@asn_primaryrefdocno_ml       = null
--if	@asn_primaryrefdocnofrom      	= '1900-01-01' select	@asn_primaryrefdocnofrom      = null
--if	@asn_primaryrefdocnoto        	= '1900-01-01' select	@asn_primaryrefdocnoto        = null
--if	@asn_primaryrefdoctype        	= '~#~' select	@asn_primaryrefdoctype        = null
--if	@asn_primaryrefdoctype_ml     	= '~#~' select	@asn_primaryrefdoctype_ml     = null
--if	@asn_reporton_btn             	= '~#~' select	@asn_reporton_btn             = null
--if	@asn_status                   	= '~#~' select	@asn_status                   = null
--if	@asn_status_ml                	= '~#~' select	@asn_status_ml                = null
--if	@asn_thuqty_ml                	= '~#~' select	@asn_thuqty_ml                = null
--if	@asn_thutype_ml               	= '~#~' select	@asn_thutype_ml               = null
--if	@asn_vehiclenumber_hdr 	= '~#~' select	@asn_vehiclenumber_hdr        = null
--if	@asn_vehicletype_hdr          	= '~#~' select	@asn_vehicletype_hdr          = null
--if	@asn_vendorcode               	= '~#~' select	@asn_vendorcode               = null
--if	@asn_vendorcode_ml            	= '~#~' select	@asn_vendorcode_ml            = null
--if	@asn_vendorname               	= '~#~' select	@asn_vendorname               = null
--if	@asn_vendorname_ml            	= '~#~' select	@asn_vendorname_ml            = null
--if	@carriername_asn_hdr          	= '~#~' select	@carriername_asn_hdr          = null
--if	@description                  	= '~#~' select	@description                  = null
--if	@equipmentnumber_asn_ml       	= '~#~' select	@equipmentnumber_asn_ml       = null
--if	@equipmenttype_asn_ml         	= '~#~' select	@equipmenttype_asn_ml         = null
--if	@guid                         	= '~#~' select	@guid                         = null
--if	@hdnbu                        	= '~#~' select	@hdnbu                        = null
--if	@hdncc                        	= '~#~' select	@hdncc                        = null
----if	@hdncsouinstance              	= '~#~' select	@hdncsouinstance              = null
--if	@hdnguid                      	= '~#~' select	@hdnguid                      = null
--if	@hdnhiddencontrol1            	= '~#~' select	@hdnhiddencontrol1            = null
--if	@hdnhiddencontrol2            	= '~#~' select	@hdnhiddencontrol2            = null
--if	@hdnlo                        	= '~#~' select	@hdnlo                        = null
----if	@hdnou                        	= '~#~' select	@hdnou                        = null
--if	@hdnrecloc                    	= '~#~' select	@hdnrecloc                    = null
--if	@hdnsrcloc                    	= '~#~' select	@hdnsrcloc                    = null
----if	@hdntimestamp                 	= -915 select	@hdntimestamp                 = null
--if	@hiddencontrol1               	= '~#~' select	@hiddencontrol1               = null
--if	@hiddencontrol2               	= '~#~' select	@hiddencontrol2               = null
--if	@hiddencontrol3               	= '~#~' select	@hiddencontrol3               = null
--if	@hiddencontrol4               	= '~#~' select	@hiddencontrol4               = null
--if	@hiddencontrol5               	= '~#~' select	@hiddencontrol5               = null
--if	@internalnotes_asn_ml         	= '~#~' select	@internalnotes_asn_ml         = null
--if	@location                     	= '~#~' select	@location                     = null
--if	@modeflag                     	= '~#~' select	@modeflag                     = null
--if	@oucodehide                   	= '~#~' select	@oucodehide                   = null
--if	@prj_hdn_ctrl                 	= '~#~' select	@prj_hdn_ctrl                 = null
--if	@report_format_hdn            	= '~#~' select	@report_format_hdn            = null
--if	@srccompcode                  	= '~#~' select	@srccompcode                  = null
--if	@txtdtformat                  	= '~#~' select	@txtdtformat                  = null
--if	@txtdtformatinthide           	= '~#~' select	@txtdtformatinthide           = null
----if	@txttimestamp                 	= -915 select	@txttimestamp                 = null
--if	@vendorasnno_asn_hdr          	= '~#~' select	@vendorasnno_asn_hdr          = null
--if	@__fprowno                    	= -915 select	@__fprowno                    = null
--if	@fprowno                      	= -915 select	@fprowno                      = null
	

	
	if not exists (
	select 'x' from asn_exec_tmp 
	--where guid	=	@guid
	)
	begin 
		RAISERROR ('Select atleast 1 ASN to generate report',16,1)
		delete from asn_exec_tmp
		RETURN
	end 




	if exists(
	select 'x' from asn_exec_tmp 
	where asn_no	<>	 @asn_asnno_ml 
	) 
	begin 
		RAISERROR ('Select Minimum 1 ASN to generate report',16,1)
		delete from asn_exec_tmp
		RETURN
	end 
	
	if not exists(select 'X' from  wms_asn_header(nolock)
	              where wms_asn_ou     = @ctxt_ouinstance
				  and   wms_asn_no     = @asn_asnno_ml
				  and   wms_asn_status = 'CNL'
				  )
				  begin
	declare @asn_format table (Contact_Name                varchar(500)
	                          ,Contact_Phone               varchar(500) 
							  ,Contact_E_Mail              varchar(500)
							  ,Seller_Name                 varchar(500)
							  ,Seller_contact              varchar(500)
							  ,Seller_ID                   varchar(500)
							  ,Delivery_facility           varchar(500)
							  ,PO                          varchar(500)
							  ,Reference                   varchar(500)
							  ,BOL                         varchar(500)
							  ,Carrier                     varchar(500)
							  ,Shipping_method             varchar(500)
							  ,Tracking                    varchar(500)
							  ,Estimated_arrival           date
							  ,Shipment_date               date
							  ,Additional_notes            varchar(500)
							  ,Total_Qty_shipped           varchar(500)
							  ,COGI_cost_of_goods_issue    varchar(500)
							  ,Products                    varchar(500)
							  ,case1                       varchar(500)
							  ,SKU                         varchar(500)
							  ,Quantity                    decimal(28,3)
							  ,LPN_no                      varchar(500)
							  ,ReportGenerated_By          varchar(500)
							  ,Report_Generated_Location   varchar(500)
							  ,location                    varchar(500)
							  ,ou                          int
							  ,shp_mode                    varchar(500)
							  ,asn_no                      varchar(500)
							  ,asn_code                    varchar(500)
							  ,uid_no                      varchar(500)
							  ,ASN_Case_SKU_Level          varchar(500)
							  ,item_code                   varchar(500)           
							  ,item_type                   varchar(500)
							  ,line_no                     int
							  ,case2                       int
							  )

	insert into @asn_format(Contact_Name         ,Contact_Phone          ,Contact_E_Mail        ,Seller_Name          ,Seller_contact         ,Seller_ID          ,location            ,Delivery_facility,PO                
	                        ,Reference            ,BOL                   ,Carrier            ,shp_mode        ,Estimated_arrival ,Shipment_date,asn_no,asn_code,uid_no
							,item_code       ,COGI_cost_of_goods_issue,Products,ou,Quantity,line_no)          
	select        distinct  cu.wms_customer_contact_person,cu.wms_customer_phone1,cu.wms_customer_email,cu.wms_customer_name,cu.wms_customer_phone1,wms_customer_id,hdr.wms_asn_location,null             ,hdr.wms_asn_prefdoc_no
	                        ,wms_asn_sup_asn_no,hdr.wms_asn_shp_ref_no ,wms_asn_shp_carrier,wms_asn_shp_mode,wms_asn_dlv_date,wms_asn_ship_date,hdr.wms_asn_no,null,wms_asn_uid
						    ,wms_asn_itm_code,hdr.wms_asn_shp_rem        ,null,hdr.wms_asn_ou,wms_asn_qty,wms_asn_lineno

   
    from		wms_asn_header hdr (nolock)
    join		wms_asn_detail dtl (nolock)
    on			hdr.wms_asn_ou             =	dtl.wms_asn_ou
	and         hdr.wms_asn_no			   =	@asn_asnno_ml
	and			hdr.wms_asn_ou			   =	@ctxt_ouinstance
    and			hdr.wms_asn_location       =	dtl.wms_asn_location        
    and			hdr.wms_asn_no             =	dtl.wms_asn_no
    left join	wms_customer_hdr  cu(nolock)
    on			cu.wms_customer_id         =	hdr.wms_asn_cust_code
    and			cu.wms_customer_ou   =	hdr.wms_asn_ou
	order by wms_asn_lineno
	
	  --update @asn_format
	  --    set case2 = tbl.cas
			-- from 
			-- (select Row_number() over (order by wms_asn_no) cas
			--              from wms_asn_detail(nolock)
			--			  where  wms_asn_no = @asn_asnno_ml
			--			  and    wms_asn_ou =	@ctxt_ouinstance  
			--			  and   wms_asn_uid is not null)tbl
                          
						  DECLARE @id INT 
                        SET @id = 0 
                         UPDATE tmp
                         SET @id = case2 =  @id + 1 
                          from @asn_format tmp,wms_asn_detail(nolock)
						  where  wms_asn_no = asn_no
						  and    wms_asn_ou =	ou  
						  and     uid_no is not null
 


						 		
								 
                  
				declare @item_type	varchar(50)
				select	@item_type = count(wms_itm_type)
				from @asn_format join wms_item_hdr
				on   item_code    = wms_itm_code

				if @item_type in (1,0)
				begin
				update tmp
				set Products = wms_itm_type
				from @asn_format tmp join wms_item_hdr
				on   item_code    = wms_itm_code
				end
				else
				begin
				update tmp 
				set Products = 'MIX'
				from @asn_format tmp join wms_item_hdr
				on   item_code    = wms_itm_code
				end
					

				



							
   update tmp
          set Total_Qty_shipped = tbl.qty
		  from @asn_format tmp,
		 ( select asn_no,sum(Quantity) qty
		 from @asn_format
		 where asn_no = @asn_asnno_ml
		 group by asn_no)tbl
		 where tmp.asn_no = tbl.asn_no
	
	
	

	update tmp
	       set   Delivery_facility = wms_loc_desc
		   from  @asn_format tmp join wms_loc_location_hdr (nolock)
	       on    wms_loc_ou		   = ou
	       and	 wms_loc_code	   = location

		   

    update tmp
	       set  Shipping_method           = md.wms_code_desc
	       from @asn_format tmp join wms_quick_code_master md(nolock) 
		   on 	md.wms_code_type		  =   'LEG_TRAN'
		   and	md.wms_code				  =   shp_mode
		   and	md.wms_code_ou			  =	  @ctxt_ouinstance
		   and	md.wms_langid			  =	  @ctxt_language

    update tmp 
	       set    Tracking = wms_asn_pop_ud_1
		   from   @asn_format tmp join wms_asn_add_dtl(nolock)adddtl
		   on     adddtl.wms_asn_pop_ou   = ou  
           and    adddtl.wms_asn_pop_loc     = location
           and    adddtl.wms_asn_pop_asn_no  = asn_no
  
    --update tmp
	   --    set Additional_notes = brin_note_description
		  -- from @asn_format tmp  join wms_quick_code_master(nolock)
		  -- on wms_code_ou    = ou
		  -- and wms_code      = shp_mode
		  -- AND wms_code_type ='internal'
    --       join tms_brin_booking_request_internal_notes(nolock)
		  -- on   brin_ouinstance  = wms_code_ou
		  -- and  brin_category    = wms_code
		  
	declare @notes varchar(Max) 
	select @notes = COALESCE(@notes + char(10) + brin_note_description, brin_note_description) 
	from tms_brin_booking_request_internal_notes(nolock)
		   where   brin_ouinstance  = @ctxt_ouinstance
		   and  brin_br_id       = @asn_asnno_ml


		  

     if exists (select 'X' 
       from @asn_format
       where asn_no  = @asn_asnno_ml
       and uid_no is null)
       begin
     if exists (select 'X'
       from @asn_format
       where asn_no  = @asn_asnno_ml
       and uid_no is not null )
       begin
      update tmp
             set ASN_Case_SKU_Level = 'Mix'
      	    from @asn_format tmp
      	    where asn_no = @asn_asnno_ml
        end
        end  
       update tmp
           set ASN_Case_SKU_Level = 'Case Level'
    	   from @asn_format tmp
    	   where asn_no = @asn_asnno_ml
    	   and   isnull(ASN_Case_SKU_Level,'') <> 'Mix'
    	   and   uid_no is not null

	   
        update tmp
           set ASN_Case_SKU_Level = 'SKU level'
    	   from @asn_format tmp
    	   where asn_no = @asn_asnno_ml
    	   and   isnull(ASN_Case_SKU_Level,'') <> 'Mix'
    	   and   uid_no is null

		   


    if exists (select * from @asn_format
          where asn_no           = @asn_asnno_ml
		  and ASN_Case_SKU_Level in ('Case Level','Mix'))
		  begin 
    update tmp
        set case1 = concat('Case',case2)
		from @asn_format tmp
		where asn_no = @asn_asnno_ml
		and   uid_no is not null
        end

		
	   if exists (select * from @asn_format
             where asn_no           = @asn_asnno_ml
	   	     and ASN_Case_SKU_Level in ('Case Level','Mix'))
	   	begin 
        update tmp
           set SKU = item_code
	   	from @asn_format tmp,wms_asn_detail(nolock)
	   	where asn_no = wms_asn_no
	   	and   uid_no = wms_asn_uid
	   	end


      if exists (select * from @asn_format
          where asn_no           = @asn_asnno_ml
		  and ASN_Case_SKU_Level in ('SKU level','Mix'))
          begin 
          update tmp
          set SKU = item_code
	      from @asn_format tmp
	      where asn_no = @asn_asnno_ml
	      end
	      

	   if exists (select * from @asn_format
          where asn_no           = @asn_asnno_ml
		  and ASN_Case_SKU_Level in ('Case Level','Mix'))
		  begin 
          update tmp
          set LPN_no = uid_no
	      from @asn_format tmp
	      end 

    --update tmp
    --   set Quantity = wms_asn_qty
	   --from @asn_format tmp join wms_asn_detail(nolock)
	   --on     asn_no      = wms_asn_no
	   --and    SKU         = wms_asn_itm_code


	   select                  count(*) over(PARTITION by asn_no) 'header'
	                          ,'company_logo.jpg'             'company_logo.jpg'
	                          ,convert(varchar,getdate(),103) 'report_date'
	                          ,Contact_Name                'Contact_Name'
	                          ,Contact_Phone               'Contact_Phone'
							  ,Contact_E_Mail              'Contact_E_Mail'
							  ,Seller_Name                 'Seller_Name'
							  ,Seller_contact              'Seller_ID1'
							  ,Seller_ID                   'Seller_ID'
							  ,Delivery_facility           'Delivery_facility'
							  ,PO                          'PO'
							  ,Reference                   'Reference'
							  ,BOL                         'BOL'
							  ,Carrier                     'Carrier'
							  ,Shipping_method             'Shipping_method'
							  ,Tracking                    'Tracking'
							  ,convert(varchar,Estimated_arrival,103)           'Estimated_arrival'
							  ,convert(varchar,Shipment_date,103)               'Shipment_date'
							  ,@notes                                  'Additional_notes'
							  ,ASN_Case_SKU_Level          'ASN_Case_SKU_Level'
							  ,Total_Qty_shipped           'Total_Qty_shipped'
							  ,COGI_cost_of_goods_issue    'COGI_cost_of_goods_issue'
							  ,Products                    'Products'
							  ,case1                       'case1'
							  ,SKU                         'SKU'
							  ,Quantity                    'Quantity'
							  ,LPN_no                      'LPN_no'
							  ,@ctxt_user          'ReportGenerated_By'
							  ,location   'Report_Generated_Location'
                              from @asn_format
                              

	   delete from asn_exec_tmp 
   
   end
   else  
	begin
	select                    
	
	                          null                 'header'
	                         ,null                 'company_logo.jpg'
	                         ,null                'report_date'
	                         ,null                'Contact_Name'
	                         ,null                'Contact_Phone'
							 ,null               'Contact_E_Mail'
							 ,null                  'Seller_Name'
							 ,null               'Seller_ID1'
							 ,null                   'Seller_ID'
							 ,null            'Delivery_facility'
							 ,null                   'PO'
							 ,null                   'Reference'
							 ,null                   'BOL'
							 ,null                   'Carrier'
							 ,null              'Shipping_method'
							 ,null                   'Tracking'
							 ,null            'Estimated_arrival'
							 ,null                'Shipment_date'
							 ,null             'Additional_notes'
							 ,null           'ASN_Case_SKU_Level'
							 ,null            'Total_Qty_shipped'
							 ,null     'COGI_cost_of_goods_issue'
							 ,null                   'Products'
							 ,null                   'case1'
							 ,null                   'SKU'
							 ,null                   'Quantity'
							 ,null                   'LPN_no'
							 ,null           'ReportGenerated_By'
							 ,null  'Report_Generated_Location'
                              
 			end					  
								  
	 							  
	 
                              
/*	
	
	select                     'header'                       'header'  
	                          ,'company_logo.jpg'             'company_logo.jpg'
	                          ,convert(varchar,getdate(),103) 'report_date'
	                          ,'Contact_Name'               'Contact_Name'
	                          ,'Contact_Phone'              'Contact_Phone'
							  ,'Contact_E_Mail'            'Contact_E_Mail'
							  ,'Seller_Name'                'Seller_Name'
							  ,'Seller_contact'             'Seller_ID1'
							  ,'Seller_ID'                  'Seller_ID'
							  ,'Delivery_facility'          'Delivery_facility'
							  ,'PO'                         'PO'
							  ,'Reference'                  'Reference'
							  ,'BOL'                        'BOL'
							  ,'Carrier'                    'Carrier'
							  ,'Shipping_method'            'Shipping_method'
							  ,'Tracking'                   'Tracking'
							  ,'Estimated_arrival'          'Estimated_arrival'
							  ,'Shipment_date'              'Shipment_date'
							  ,'Additional_notes'           'Additional_notes'
							  ,'ASN_Case_SKU_Level'         'ASN_Case_SKU_Level'
							  ,'Total_Qty_shipped'          'Total_Qty_shipped'
							  ,'COGI_cost_of_goods_isse'    'COGI_cost_of_goods_issue'
							  ,'Products'                   'Products'
							  ,'case1'                      'case1'
							  ,'SKU'                        'SKU'
							  ,'Quantity'                   'Quantity'
							  ,'LPN_no'                     'LPN_no'
							  ,'ReportGenerated_By'         'ReportGenerated_By'
							  ,'Report_Generated_Location'   'Report_Generated_Location'
                              
   
 */ 
 
	
	--where guid	=	@guid




Set nocount off
End

go
if exists ( select 'y' from sysobjects where name = 'asn_format_report' and type = 'P')
	grant exec on asn_format_report to public
go
