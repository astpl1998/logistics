if exists ( select 'y' from sysobjects where name = 'log_dvert_asn_worksheet_sp' and type = 'P')
	drop proc log_dvert_asn_worksheet_sp
go

CREATE procedure log_dvert_asn_worksheet_sp
(

	@ctxt_user                     Ctxt_User,
	@ctxt_role                     Ctxt_Role,
	@ctxt_ouinstance               Ctxt_OUInstance,
	@ctxt_language                 Ctxt_Language,
	@_reportformat                 _desc255,
	@asn_asndate_ml                date,
	@asn_asndatefrom               date,
	--@asn_asndateto                 date,
	@asn_asnno_ml                  documentno,
	@asn_asnnofrom                 desc20,
	@asn_asnnoto                   desc20
	--@asn_customercode              desc20,
	--@asn_customercode_ml           documentno,
	--@asn_customeritemcode_ml       ItemCode,
	--@asn_customername              desc40,
	--@asn_customername_ml           desc40,
	--@asn_equipmentnumber_hdr       MoCode,
	--@asn_equipmenttype_hdr         desc40,
	--@asn_expecteddeliverydate_ml   DateTime1,
	--@asn_hdn_char_01               desc255,
	--@asn_hdn_char_02               desc255,
	--@asn_hdn_char_03               desc255,
	--@asn_hdn_int_01                HrInt,
	--@asn_hdn_int_02                HrInt,
	--@asn_hidden_1                  HrInt,
	--@asn_hub_deliverydate_hdr      date,
	--@asn_inboundorderdate_ml       date,
	--@asn_inboundorderdatefrom      date,
	--@asn_inboundorderdateto        date,
	--@asn_inboundorderno_ml         documentno,
	--@asn_inboundordernofrom        desc20,
	--@asn_inboundordernoto          desc20,
	--@asn_itemcode_ml               ItemCode,
	--@asn_itemdesc_ml               desc255,
	--@asn_masteruom_ml              Uomcode,
	--@asn_orderqty_ml               wms_quantity,
	--@asn_primaryrefdocdatefromhdr  date,
	--@asn_primaryrefdocno_ml        documentno,
	--@asn_primaryrefdocnofrom       desc20,
	--@asn_primaryrefdocnoto         date,
	--@asn_primaryrefdoctype         desc20,
	--@asn_primaryrefdoctype_ml      desc255,
	--@asn_reporton_btn              desc255,
	--@asn_status                    desc20,
	--@asn_status_ml                 desc255,
	--@asn_thuqty_ml                 wms_quantity,
	--@asn_thutype_ml                desc40,
	--@asn_vehiclenumber_hdr         ParamCode,
	--@asn_vehicletype_hdr           desc40,
	--@asn_vendorcode                suppliercode,
	--@asn_vendorcode_ml             suppliercode,
	--@asn_vendorname                SupplierName,
	--@asn_vendorname_ml             SupplierName,
	--@carriername_asn_hdr           Customer_Name,
	--@description                   desc255,
	--@equipmentnumber_asn_ml        MoCode,
	--@equipmenttype_asn_ml          desc40,
	--@guid                          GUID
	--@hdnbu                         desc255,
	--@hdncc                         desc255,
	--@hdncsouinstance               Ctxt_OUInstance,
	--@hdnguid                       desc255
	--@hdnhiddencontrol1             desc255,
	--@hdnhiddencontrol2             desc255,
	--@hdnlo                         desc255,
	--@hdnou                         Ctxt_OUInstance,
	--@hdnrecloc                     desc255,
	--@hdnsrcloc                     desc255,
	
	--@hiddencontrol1                desc255,
	--@hiddencontrol2                desc255,
	--@hiddencontrol3                desc255,
	--@hiddencontrol4                desc255,
	--@hiddencontrol5                desc255,
	--@internalnotes_asn_ml          desc255,
	----@location                      Warehouse,
	--@modeflag                      ModeFlag,
	--@oucodehide                    Ctxt_OUInstance,
	--@prj_hdn_ctrl                  desc255,
	--@report_format_hdn             _desc255,
	--@srccompcode                   desc255,
	--@txtdtformat                   desc255,
	--@txtdtformatinthide            desc255,
	
	--@vendorasnno_asn_hdr           documentno,
	--@__fprowno                     rowno,
	--@fprowno                       rowno

) 

as 

begin /*procedure begin */


set NOCOUNT on 



if	@ctxt_user						= '~#~' select	@ctxt_user                    = null
if	@ctxt_role    	= '~#~' select	@ctxt_role                    = null
if	@ctxt_ouinstance              	= -915  select	@ctxt_ouinstance              = null
if	@ctxt_language                	= -915 select	@ctxt_language                = null
if	@_reportformat                	= '~#~' select	@_reportformat                = null
if	@asn_asndate_ml               	= '1900-01-01' select	@asn_asndate_ml               = null
if	@asn_asndatefrom              	= '1900-01-01' select	@asn_asndatefrom              = null
--if	@asn_asndateto                	= '1900-01-01' select	@asn_asndateto                = null
if	@asn_asnno_ml                 	= '~#~' select	@asn_asnno_ml                 = null
if	@asn_asnnofrom                	= '~#~' select	@asn_asnnofrom                = null
if	@asn_asnnoto                  	= '~#~' select	@asn_asnnoto                  = null



/*
if	@asn_customercode             	= '~#~' select	@asn_customercode             = null
if	@asn_customercode_ml          	= '~#~' select	@asn_customercode_ml          = null
if	@asn_customeritemcode_ml      	= '~#~' select	@asn_customeritemcode_ml      = null
if	@asn_customername             	= '~#~' select	@asn_customername             = null
if	@asn_customername_ml          	= '~#~' select	@asn_customername_ml          = null
if	@asn_equipmentnumber_hdr      	= '~#~' select	@asn_equipmentnumber_hdr      = null
if	@asn_equipmenttype_hdr        	= '~#~' select	@asn_equipmenttype_hdr        = null
if	@asn_expecteddeliverydate_ml  	= '~#~' select	@asn_expecteddeliverydate_ml  = null
if	@asn_hdn_char_01              	= '~#~' select	@asn_hdn_char_01              = null
if	@asn_hdn_char_02              	= '~#~' select	@asn_hdn_char_02              = null
if	@asn_hdn_char_03              	= '~#~' select	@asn_hdn_char_03              = null
if	@asn_hdn_int_01               	= '~#~' select	@asn_hdn_int_01               = null
if	@asn_hdn_int_02               	= '~#~' select	@asn_hdn_int_02               = null
if	@asn_hidden_1                 	= '~#~' select	@asn_hidden_1                 = null
if	@asn_hub_deliverydate_hdr     	= '~#~' select	@asn_hub_deliverydate_hdr     = null
if	@asn_inboundorderdate_ml      	= '~#~' select	@asn_inboundorderdate_ml      = null
if	@asn_inboundorderdatefrom     	= '1900-01-01' select	@asn_inboundorderdatefrom     = null
if	@asn_inboundorderdateto       	= '1900-01-01' select	@asn_inboundorderdateto       = null
if	@asn_inboundorderno_ml        	= '~#~' select	@asn_inboundorderno_ml        = null
if	@asn_inboundordernofrom       	= '1900-01-01' select	@asn_inboundordernofrom       = null
if	@asn_inboundordernoto         	= '1900-01-01' select	@asn_inboundordernoto         = null
if	@asn_itemcode_ml              	= '~#~' select	@asn_itemcode_ml              = null
if	@asn_itemdesc_ml              	= '~#~' select	@asn_itemdesc_ml              = null
if	@asn_masteruom_ml             	= '~#~' select	@asn_masteruom_ml             = null
if	@asn_orderqty_ml              	= '~#~' select	@asn_orderqty_ml              = null
if	@asn_primaryrefdocdatefromhdr 	= '~#~' select	@asn_primaryrefdocdatefromhdr = null
if	@asn_primaryrefdocno_ml       	= '~#~' select	@asn_primaryrefdocno_ml       = null
if	@asn_primaryrefdocnofrom      	= '1900-01-01' select	@asn_primaryrefdocnofrom      = null
if	@asn_primaryrefdocnoto        	= '1900-01-01' select	@asn_primaryrefdocnoto        = null
if	@asn_primaryrefdoctype        	= '~#~' select	@asn_primaryrefdoctype        = null
if	@asn_primaryrefdoctype_ml     	= '~#~' select	@asn_primaryrefdoctype_ml     = null
if	@asn_reporton_btn             	= '~#~' select	@asn_reporton_btn             = null
if	@asn_status                   	= '~#~' select	@asn_status                   = null
if	@asn_status_ml                	= '~#~' select	@asn_status_ml                = null
if	@asn_thuqty_ml                	= '~#~' select	@asn_thuqty_ml                = null
if	@asn_thutype_ml               	= '~#~' select	@asn_thutype_ml               = null
if	@asn_vehiclenumber_hdr        	= '~#~' select	@asn_vehiclenumber_hdr        = null
if	@asn_vehicletype_hdr          	= '~#~' select	@asn_vehicletype_hdr          = null
if	@asn_vendorcode               	= '~#~' select	@asn_vendorcode               = null
if	@asn_vendorcode_ml            	= '~#~' select	@asn_vendorcode_ml            = null
if	@asn_vendorname               	= '~#~' select	@asn_vendorname               = null
if	@asn_vendorname_ml            	= '~#~' select	@asn_vendorname_ml            = null
if	@carriername_asn_hdr          	= '~#~' select	@carriername_asn_hdr          = null
if	@description                  	= '~#~' select	@description                  = null
if	@equipmentnumber_asn_ml       	= '~#~' select	@equipmentnumber_asn_ml       = null
if	@equipmenttype_asn_ml         	= '~#~' select	@equipmenttype_asn_ml         = null
if	@guid                         	= '~#~' select	@guid                         = null
if	@hdnbu                        	= '~#~' select	@hdnbu                        = null
if	@hdncc                        	= '~#~' select	@hdncc                        = null
--if	@hdncsouinstance              	= '~#~' select	@hdncsouinstance              = null
if	@hdnguid                      	= '~#~' select	@hdnguid                      = null
if	@hdnhiddencontrol1            	= '~#~' select	@hdnhiddencontrol1            = null
if	@hdnhiddencontrol2            	= '~#~' select	@hdnhiddencontrol2            = null
if	@hdnlo                        	= '~#~' select	@hdnlo                        = null
--if	@hdnou                        	= '~#~' select	@hdnou                        = null
if	@hdnrecloc                    	= '~#~' select	@hdnrecloc                    = null
if	@hdnsrcloc                    	= '~#~' select	@hdnsrcloc                    = null
--if	@hdntimestamp                 	= -915 select	@hdntimestamp                 = null
if	@hiddencontrol1               	= '~#~' select	@hiddencontrol1               = null
if	@hiddencontrol2               	= '~#~' select	@hiddencontrol2               = null
if	@hiddencontrol3               	= '~#~' select	@hiddencontrol3               = null
if	@hiddencontrol4               	= '~#~' select	@hiddencontrol4               = null
if	@hiddencontrol5               	= '~#~' select	@hiddencontrol5               = null
if	@internalnotes_asn_ml         	= '~#~' select	@internalnotes_asn_ml         = null
--if	@location                     	= '~#~' select	@location                     = null
if	@modeflag                     	= '~#~' select	@modeflag                     = null
if	@oucodehide                   	= '~#~' select	@oucodehide                   = null
if	@prj_hdn_ctrl                 	= '~#~' select	@prj_hdn_ctrl                 = null
if	@report_format_hdn            	= '~#~' select	@report_format_hdn            = null
if	@srccompcode                  	= '~#~' select	@srccompcode                  = null
if	@txtdtformat                  	= '~#~' select	@txtdtformat                  = null
if	@txtdtformatinthide           	= '~#~' select	@txtdtformatinthide           = null
--if	@txttimestamp                 	= -915 select	@txttimestamp                 = null
if	@vendorasnno_asn_hdr          	= '~#~' select	@vendorasnno_asn_hdr          = null
if	@__fprowno                    	= -915 select	@__fprowno                    = null
if	@fprowno                      	= -915 select	@fprowno                      = null

*/





	--if not exists (
	--select 'x' from asn_exec_tmp 
	----where guid	=	@guid
	--)
	--begin 
	--	RAISERROR ('Select atleast 1 ASN to generate report ',16,1)
	--	delete from asn_exec_tmp
	--	RETURN
	--end 

	
	declare @asn_exec_tmp table
	(
	asn_no	documentno,
	guid	guid
	)

	insert into @asn_exec_tmp
	(
	asn_no,	
	guid	
	)
	select distinct 
	asn_no,	
	guid	
	from  asn_exec_tmp





	declare @asn_report_TMP TABLE
	(
	auto_no						int identity(1,1)
	,line_no					int 
	, master_ou					int
	,ASN_NO						nvarchar(200)
	,Date1						datetime 
	,Seller_ID					nvarchar(200)
	,Seller_Name				nvarchar(200)
	,Shipment_ID				nvarchar(200)
	,ASN_Barcode				nvarchar(200)
	,wms_asn_uid_case_shu		nvarchar(200)
	,case_sku_rowno				int
	,PalletizedY_N				nvarchar(200)
	,Case_level_SKU_ASN			nvarchar(200)
	,Case_SKU_ID_Barcode		nvarchar(200)
	,Shipped_Qty				numeric(18,3)
	,Case_pallet_Qty			numeric(18,3)
	,Dimensions_available		nvarchar(200)
	,QA_neededY_N				nvarchar(200)
	,GTP_eligibleY_N			nvarchar(200)
	,report_date1				datetime 
	,report_generated_by		nvarchar(200)
	,report_generated_location	nvarchar(200)
	,wms_asn_location			nvarchar(200) 
	,wms_itm_weight				nvarchar(200)
	,wms_itm_length				nvarchar(200)
	,wms_itm_breadth			nvarchar(200)
	,wms_itm_height				nvarchar(200)
	,wms_asn_itm_code			nvarchar(200)
	,wms_asn_uid				nvarchar(200)
	,wms_asn_thu_srl_no			nvarchar(200)
	,line_num                   int
	,case2                      int
	,uid_no                    varchar(100)
	)


	insert into @asn_report_TMP 
	(
	 line_no
	,master_ou					
	,Date1						
	,Seller_ID					
	,Seller_Name				
	,Shipment_ID				
	,ASN_No						
	,ASN_Barcode	
	
	,wms_asn_uid_case_shu

	,case_sku_rowno
	,PalletizedY_N				
	,Case_level_SKU_ASN			
	,Case_SKU_ID_Barcode		
	,Shipped_Qty				
	,Case_pallet_Qty			
	,Dimensions_available		
	,QA_neededY_N				
	,GTP_eligibleY_N			
	,report_date1				
	,report_generated_by		
	,report_generated_location	
	,wms_asn_location
	,wms_asn_itm_code
	,wms_asn_uid
	,wms_asn_thu_srl_no
	,line_num
	,uid_no
	)

	select 
	row_number() over (order by wms_asn_uid),
	hdr.wms_asn_ou				,
	hdr.wms_asn_date			,
	hdr.wms_asn_cust_code		,
	CU.wms_customer_name		,
	adddtl.wms_asn_pop_ud_1		,
	hdr.wms_asn_no				,
	hdr.wms_asn_no				
	,CASE WHEN dtl.wms_asn_uid IS NOT NULL THEN 'CASE' else 'SKU'  END  
	,row_number() over (partition by hdr.wms_asn_no,CASE WHEN dtl.wms_asn_uid IS NOT NULL THEN '1' else '2' END  order by hdr.wms_asn_no,CASE WHEN dtl.wms_asn_uid IS NOT NULL THEN '1' else '2' END  )
	,case when dtl.wms_asn_thu_srl_no is null then 'NO'ELSE 'YES' END    	
	,CASE WHEN dtl.wms_asn_uid IS NOT NULL THEN  dtl.wms_asn_uid else  wms_asn_itm_code END  
	,CASE WHEN dtl.wms_asn_uid IS NOT NULL THEN  dtl.wms_asn_uid else  wms_asn_itm_code END  ,
	null						,
	wms_asn_qty					,
	NULL,
	NULL,
	NULL,
	getdate(),
	@ctxt_user,
	dtl.wms_asn_location,
	dtl.wms_asn_location,
	dtl.wms_asn_itm_code,
	dtl.wms_asn_uid,		
	dtl.wms_asn_thu_srl_no,	
	dtl.wms_asn_lineno,
	dtl.wms_asn_uid

	from			wms_asn_header	hdr	(nolock)
	left  join		wms_asn_detail	dtl	(nolock)
	on				hdr.wms_asn_ou				=	dtl.wms_asn_ou
	and				hdr.wms_asn_location		=	dtl.wms_asn_location
	and				hdr.wms_asn_no				=	dtl.wms_asn_no				
	left join		wms_customer_hdr  cu (nolock)
	on				cu.wms_customer_id			=	hdr.wms_asn_cust_code
	and				cu.wms_customer_ou			=	hdr.wms_asn_ou
	left join		wms_asn_add_dtl adddtl (nolock)
	on				adddtl.wms_asn_pop_ou		=	hdr.wms_asn_ou		
	and				adddtl.wms_asn_pop_loc		=	hdr.wms_asn_location
	and				adddtl.wms_asn_pop_asn_no	=	hdr.wms_asn_no	
	join			@asn_exec_tmp t1
	on				t1.asn_no					=	hdr.wms_asn_no	
	WHERE			hdr.wms_asn_ou				=	@ctxt_ouinstance
	and				hdr.wms_asn_status	in  ('FR','AU','CL')
	order by wms_asn_lineno 

	/*


						 UPDATE tmp
                         SET  case2 = rn
						 from
						  (select case_sku_rowno,asn_no,row_number() over(partition by asn_no order by uid_no,case_sku_rowno,asn_no,uid_no) 'rn'
                          from @asn_report_TMP tmp						  ) a
						join @asn_report_TMP tmp
						on a.asn_no = tmp.asn_no
						and a.case_sku_rowno = tmp.case_sku_rowno
						and wms_asn_uid_case_shu = 'CASE'

						
						  update tmp
						         set Case_level_SKU_ASN   = concat('CASE',' ',case2,'  ',Case_level_SKU_ASN)
								     ,Case_SKU_ID_Barcode = concat('CASE',' ',case2,'  ',Case_SKU_ID_Barcode)
								 from @asn_report_TMP tmp,@asn_exec_tmp tab
								 where  tmp.asn_no = tab.asn_no
								 and wms_asn_uid_case_shu = 'CASE'

						
						
						 UPDATE tmp
                                SET  case2 = rn
						       from
						        (select case_sku_rowno,asn_no,row_number() over(partition by asn_no order by uid_no,case_sku_rowno,asn_no,uid_no) 'rn'
                                from @asn_report_TMP tmp						  ) a
						        join @asn_report_TMP tmp
						        on a.asn_no = tmp.asn_no
						        and a.case_sku_rowno = tmp.case_sku_rowno
						        and tmp.uid_no is not null
						        and wms_asn_uid_case_shu = 'mix'

						  
						  update tmp
						         set Case_level_SKU_ASN   = concat('CASE',' ',case2,'  ',Case_level_SKU_ASN)
								     ,Case_SKU_ID_Barcode = concat('CASE',' ',case2,'  ',Case_SKU_ID_Barcode)
								 from @asn_report_TMP tmp,@asn_exec_tmp tab
								 where  tmp.asn_no        = tab.asn_no
								 and tmp.uid_no is not null
								 and wms_asn_uid_case_shu = 'mix'
								 
								 
						  
				  		 UPDATE tmp
                         SET  case2 = rn
						 from
						  (select line_num,asn_no,row_number() over(partition by asn_no order by asn_no,uid_no) 'rn'
                          from @asn_report_TMP tmp						  ) a
						  join @asn_report_TMP tmp
						  on  a.asn_no   = tmp.asn_no
						  and a.line_num = tmp.line_num
						  and   uid_no is  null
						  and wms_asn_uid_case_shu =  'mix'

						  update tmp
						         set Case_level_SKU_ASN  = concat('SKU',' ',case2,'  ',Case_level_SKU_ASN)
								    ,Case_SKU_ID_Barcode = concat('SKU',' ',case2,'  ',Case_SKU_ID_Barcode)
								 from @asn_report_TMP tmp,@asn_exec_tmp tab
								 where  tmp.asn_no = tab.asn_no
								 and   uid_no is  null
								 and  wms_asn_uid_case_shu =  'mix'


				  		 UPDATE tmp
                         SET  case2 = rn
						 from
						  (select line_num,asn_no,row_number() over(partition by asn_no order by asn_no,uid_no) 'rn'
                          from @asn_report_TMP tmp						  ) a
						join @asn_report_TMP tmp
						on  a.asn_no   = tmp.asn_no
						and a.line_num = tmp.line_num
						--and   uid_no is  null
						and wms_asn_uid_case_shu =  'SKU'
						 
						        update tmp
						         set Case_level_SKU_ASN  = concat('SKU',' ',case2,'  ',Case_level_SKU_ASN)
								    ,Case_SKU_ID_Barcode = concat('SKU',' ',case2,'  ',Case_SKU_ID_Barcode)
								 from @asn_report_TMP tmp,@asn_exec_tmp tab
								 where  tmp.asn_no = tab.asn_no
								 and  wms_asn_uid_case_shu =  'SKU'
								
				*/

	--update	TMP
	--set		Case_level_SKU_ASN	=	wms_asn_uid_case_shu + ' '+	cast (case_sku_rowno as nvarchar(50)) + ' ' + Case_level_SKU_ASN 
	--FROM	@asn_report_TMP TMP 

 
	 UPDATE TMP
	 SET	Shipped_Qty	=	X.QTY
	 FROM @asn_report_TMP TMP
	 JOIN
	 (
	 SELECT 
	 SUM(wms_asn_qty)		 'QTY',
	 wms_asn_ou				 'OU',		
	 wms_asn_no				 'ASN',
	 wms_asn_location		 'LOCATION',
	 CASE WHEN dtl.wms_asn_uid IS NOT NULL THEN 'CASE' else 'SKU'  END  	 'cs_sku'
	 FROM wms_asn_detail	dtl	(nolock)
	 GROUP BY 
	  wms_asn_ou			
	 ,wms_asn_no				
	 ,wms_asn_location	
	 ,CASE WHEN dtl.wms_asn_uid IS NOT NULL THEN 'CASE' else 'SKU'  END
	 
	 )X
	 ON		TMP.master_ou				= X.OU	
	 and	TMP.ASN_No					= X.ASN
	 and	TMP.wms_asn_location		= X.LOCATION 
	 and	TMP.wms_asn_uid_case_shu	= x.cs_sku

	 /*
	 UPDATE TMP
	 SET	Case_pallet_Qty	=	X.QTY
	 FROM @asn_report_TMP TMP
	 JOIN
	 (
	 SELECT 
	 SUM(Shipped_Qty)		 'QTY',
	 master_ou				 'OU',		
	 ASN_No					 'ASN',
	 wms_asn_location		 'LOCATION',
	 Case_level_SKU_ASN		 'CASE_SKU'

	 FROM @asn_report_TMP 
	 GROUP BY 
	 master_ou			
	 ,ASN_No				
	 ,wms_asn_location	
	 ,Case_level_SKU_ASN
	 )X
	 ON		TMP.master_ou				= X.OU	
	 and	TMP.ASN_No					= X.ASN
	 and	TMP.wms_asn_location		= X.LOCATION
	 AND	TMP.Case_level_SKU_ASN		= X.CASE_SKU
	 */

	update	 tmp 
	set		 wms_itm_weight		=	itm.wms_itm_weight	
			,wms_itm_length		=	itm.wms_itm_length	
			,wms_itm_breadth	=	itm.wms_itm_breadth
			,wms_itm_height		=	itm.wms_itm_height	
	from	@asn_report_TMP tmp
	join	wms_item_hdr(nolock) itm
	ON		wms_itm_code		=	tmp.wms_asn_itm_code
	and		wms_itm_ou			=	TMP.MASTER_OU


	update	tmp 
	SET		Dimensions_available	=	'No'
	from	@asn_report_TMP tmp
	where   (wms_itm_weight		is null or
			wms_itm_length		is null or
			wms_itm_breadth		is null or
			wms_itm_height		is null) 
	--and		Case_level_SKU_ASN	like 'sku%'

	update	tmp 
	SET		Dimensions_available	=	'YES'
	from	@asn_report_TMP tmp
	where   wms_itm_weight		is NOT null 
	AND		wms_itm_length		is NOT null  
	AND		wms_itm_breadth		is NOT null  
	AND		wms_itm_height		is NOT null  
	--and		Case_level_SKU_ASN	like 'sku%'


	update	tmp 
	set		Case_SKU_ID_Barcode		=	isnull(dtl.wms_itm_barcode,dtl.wms_itm_code) 
	from 	@asn_report_TMP tmp 
	JOIN	wms_item_other_part_info_dtl	dtl(nolock)
	ON		dtl.wms_itm_code		=	tmp.Case_SKU_ID_Barcode
	and		dtl.wms_itm_ou			=	TMP.MASTER_OU



	update	tmp 
	set		QA_neededY_N	=	'No' 
	from	@asn_report_TMP tmp


	--declare @count int  
	--select @count	=	count(*) from  @asn_report_TMP

	--declare @d int = 1


	--while (@count >= @d)
	--begin 

	--declare @asn_no	nvarchar(200)

	--select	@asn_no		=  ASN_No 
	--from	@asn_report_TMP
	--where	auto_no		=	@d





	--SET @d = @d +1
	--end



	if exists(
		select	count(wms_asn_itm_code)
				wms_asn_uid,
				ASN_No
		from	@asn_report_TMP tmp
		group by 
		wms_asn_uid,
		ASN_No 
		having count(wms_asn_itm_code) > 1
		)
		begin ----->1 

			if exists(
				select	 count(Case_level_SKU_ASN)
						 wms_asn_thu_srl_no,
						 ASN_No
				from	 @asn_report_TMP tmp
				where	 Case_level_SKU_ASN	like 'SKU%'
				group by wms_asn_thu_srl_no,
						 ASN_No 
				having count(Case_level_SKU_ASN) > 1
				)
			BEGIN ----->2 

				IF EXISTS (
						SELECT * FROM @asn_report_TMP tmp
						WHERE	 wms_itm_weight		is null or
								 wms_itm_length		is null or
								 wms_itm_breadth	is null or
								 wms_itm_height		is null
							)
				BEGIN ----->3
				
					update	tmp 
					set		QA_neededY_N	=	'yes' 
					from	@asn_report_TMP tmp

				
				END ----->3			

			END ----->2

		end ----->1


		--update	tmp 
		--			set		QA_neededY_N	=	'yes' 
		--			from	@asn_report_TMP tmp
		--			WHERE	( wms_itm_weight		is null or
		--						 wms_itm_length		is null or
		--						 wms_itm_breadth	is null or
		--						 wms_itm_height		is null )




		UPDATE	tmp
		SET		GTP_eligibleY_N	=	NULL
		FROM	@asn_report_TMP tmp

		--select 'testing',* from @asn_report_TMP


		select 'company_logo.jpg'             'company_logo.jpg'  
		,master_ou					          'master_ou'				
		,convert(varchar,Date1,103)		      'Date1'					
		,Seller_ID					          'Seller_ID'				
		,Seller_Name				          'Seller_Name'				
		,Shipment_ID				          'Shipment_ID'				
		,ASN_No						          'ASN_No'					
		,ASN_Barcode				          'ASN_Barcode'				
		,PalletizedY_N				          'PalletizedY_N'			
		,Case_level_SKU_ASN			          'Case_level_SKU_ASN'		
		,Case_SKU_ID_Barcode		          'Case_SKU_ID_Barcode'		
		,Shipped_Qty				          'Shipped_Qty'				
		,Case_pallet_Qty			          'Case_pallet_Qty'			
		,Dimensions_available		          'Dimensions_available'	
		,QA_neededY_N				          'QA_neededY_N'			
		,GTP_eligibleY_N			          'GTP_eligibleY_N'			
		,convert(varchar,report_date1,103)	  'report_date1'				
		,report_generated_by		          'report_generated_by'		
		,report_generated_location	          'report_generated_location'
		,wms_asn_uid_case_shu		          'wms_asn_uid_case_shu'

		FROM @asn_report_TMP
		order by ASN_No


		delete from  asn_exec_tmp

/*

	select  'company_logo.jpg'             'company_logo.jpg'
	    ,'master_ou'			                        'master_ou'					
		,'Date1'										'Date1'					
		,'Seller_ID'									'Seller_ID'				
		,'Seller_Name'								'Seller_Name'				
		,'Shipment_ID'								'Shipment_ID'				
		,'ASN_No'									'ASN_No'					
		,'ASN_Barcode'								'ASN_Barcode'				
		,'PalletizedY_N'							'PalletizedY_N'			
		,'Case_level_SKU_ASN'						'Case_level_SKU_ASN'		
		,'Case_SKU_ID_Barcode'						'Case_SKU_ID_Barcode'		
		,'Shipped_Qty'								'Shipped_Qty'				
		,'Case_pallet_Qty'							'Case_pallet_Qty'			
		,'Dimensions_available'						'Dimensions_available'	
		,'QA_neededY_N'								'QA_neededY_N'			
		,'GTP_eligibleY_N'							'GTP_eligibleY_N'			
		,'report_date1'								'report_date1'				
		,'report_generated_by'						'report_generated_by'		
		,'report_generated_location'				'report_generated_location'
		,'wms_asn_uid_case_shu'						'wms_asn_uid_case_shu'

		
		*/
		--where guid	=	@guid


set NOCOUNT OFF



end /*procedure end */












go
if exists ( select 'y' from sysobjects where name = 'log_dvert_asn_worksheet_sp' and type = 'P')
	grant exec on log_dvert_asn_worksheet_sp to public
go
