/*$$filename = wma_asnhb_m_fet_hdrfet_state_i.sql*/
If exists ( Select 'y' from sysobjects where name = 'wma_asnhb_m_fet_hdrfet_state_i' and type = 'P')
	drop proc wma_asnhb_m_fet_hdrfet_state_i
Go

/********************************************************************************/
/* Procedure    :WMA_AsnHb_M_fet_HdrFet_state_i                                 */
/* Description  :                                                               */
/********************************************************************************/
/* Customer     :dvita                                                          */
/* Project      :dvita                                                          */
/********************************************************************************/
/* Referenced   :                                                               */
/* Tables       :                                                               */
/********************************************************************************/
/* Development History                                                          */
/********************************************************************************/
/* Author       :amitysoft                                                      */
/* Date         :4/26/2018 12:03:15 PM                                          */
/********************************************************************************/
/* Modification History                                                         */
/********************************************************************************/
/* Modified by  :                                                               */
/* Date         :                                                               */
/* Description  :                                                               */
/********************************************************************************/

Create procedure wma_asnhb_m_fet_hdrfet_state_i                                        
	@ctxt_user                     Ctxt_User,
	@ctxt_service                  Ctxt_Service,
	@ctxt_role                     Ctxt_Role,
	@ctxt_ouinstance               Ctxt_OUInstance,
	@ctxt_language                 Ctxt_Language,
	@m_errorid                     int output

as
Begin

	Set nocount on

	Select @ctxt_user                     =ltrim(rtrim(@ctxt_user))
	Select @ctxt_service                  =ltrim(rtrim(@ctxt_service))
	Select @ctxt_role                     =ltrim(rtrim(@ctxt_role))
	-- @m_errorid should be 0 to Indicate Success
	Set @m_errorid = 0


	--null checking
	If @ctxt_user='~#~'
		Select @ctxt_user=null
	If @ctxt_service='~#~'
		Select @ctxt_service=null
	If @ctxt_role='~#~'
		Select @ctxt_role=null
	If @ctxt_ouinstance=-915
		Select @ctxt_ouinstance=null
	If @ctxt_language=-915
		Select @ctxt_language=null

	--errors mapped
	Select  
		'btn_combo_init'           'hdnappstate_control'
	--output parameters
	/*
	Select  
		hdnappstate_control           'hdnappstate_control'

	*/
	Set nocount off
End
Go

If Exists ( Select 'y' from sysobjects where name = 'wma_asnhb_m_fet_hdrfet_state_i' and type = 'P')
	grant exec on wma_asnhb_m_fet_hdrfet_state_i to public
Go

